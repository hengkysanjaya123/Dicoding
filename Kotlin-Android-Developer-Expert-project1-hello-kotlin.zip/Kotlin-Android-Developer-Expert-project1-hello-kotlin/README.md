# Kotlin-Android-Developer-Expert
Repositori ini berisi semua project yang ada di [Kotlin Android Developer Expert][kotlin-android-developer-expert]. Untuk beralih ke project yang lain, Anda bisa memilih project pada menu `branch`.

Ingin Belajar bahasa Kotlin untuk menjadi Kotlin Android Developer Expert?

Peserta akan mempelajari tentang dasar-dasar bahasa pemrograman Kotlin, penerapan Kotlin dalam pengembangan aplikasi Android, Kotlin Android Extensions, Anko, mengambil data dari API, SQLite di dalam Kotlin, Kotlin Coroutines, dan juga Testing.

Silahkan daftar di [dicoding.id/a/55][kotlin-android-developer-expert].

[kotlin-android-developer-expert]: https://www.dicoding.com/academies/55/
