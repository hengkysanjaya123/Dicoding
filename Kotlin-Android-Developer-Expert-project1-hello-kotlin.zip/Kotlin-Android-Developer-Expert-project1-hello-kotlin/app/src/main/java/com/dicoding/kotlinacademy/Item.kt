package com.dicoding.kotlinacademy

/**
 * Created by root on 1/16/18.
 */
data class Item (val name: String?, val image: Int?)