package com.example.itss_wsc.myapplication

interface FragmentSearchInterface {
    fun OnSearch(query: String)
}